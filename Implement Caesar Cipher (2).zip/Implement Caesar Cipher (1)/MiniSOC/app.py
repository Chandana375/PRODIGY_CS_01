from flask import Flask, request, render_template_string
import datetime, os

app = Flask(__name__)
LOG = "soc.log"

# Logging function
def log(event):
    with open(LOG, "a") as f:
        f.write(f"{datetime.datetime.now()} | {event}\n")

# Caesar Cipher
def caesar(text, shift):
    result = ""
    for c in text:
        if c.isalpha():
            base = 65 if c.isupper() else 97
            result += chr((ord(c) - base + shift) % 26 + base)
        else:
            result += c
    return result

# Read logs
def read_logs():
    if os.path.exists(LOG):
        with open(LOG) as f:
            return f.readlines()
    return []

# Single route
@app.route("/", methods=["GET", "POST"])
def home():
    result = ""
    logs = read_logs()
    error = ""

    if request.method == "POST":
        text = request.form.get("text", "")
        shift_val = request.form.get("shift", "")
        action = request.form.get("action")

        try:
            shift = int(shift_val)
        except:
            error = "Shift must be a valid number!"
            shift = 0

        if not error:
            if action == "Encrypt":
                result = caesar(text, shift)
                log("ENCRYPT")

            elif action == "Decrypt":
                result = caesar(text, -shift)
                log("DECRYPT")

            elif action == "Brute":
                result = "\n".join(
                    [f"Shift {i}: {caesar(text, -i)}" for i in range(26)]
                )
                log("BRUTE FORCE")

    # Inline HTML (dashboard)
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Mini SOC Dashboard</title>
        <style>
            body { font-family: Arial; background:#0f172a; color:white; text-align:center; }
            input, button { padding:10px; margin:5px; border-radius:5px; border:none; }
            button { background:#22c55e; cursor:pointer; }
            button:hover { background:#16a34a; }
            .box { background:#1e293b; padding:20px; margin:20px auto; width:60%; border-radius:10px; }
            pre { text-align:left; white-space:pre-wrap; }
            .error { color:red; }
        </style>
    </head>
    <body>

    <h1>Mini SOC Toolkit Dashboard</h1>

    <div class="box">
        <form method="POST">
            <input type="text" name="text" placeholder="Enter text" required><br>
            <input type="text" name="shift" placeholder="Shift value"><br>

            <button name="action" value="Encrypt">Encrypt</button>
            <button name="action" value="Decrypt">Decrypt</button>
            <button name="action" value="Brute">Brute Force</button>
        </form>
    </div>

    <div class="box">
        <h3>Result</h3>
        <pre>{{result}}</pre>

        <p class="error">{{error}}</p>
    </div>

    <div class="box">
        <h3>SOC Logs</h3>
        <pre>
{% for log in logs %}
{{log}}
{% endfor %}
        </pre>
    </div>

    </body>
    </html>
    """

    return render_template_string(html, result=result, logs=logs, error=error)

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)