from flask import Flask, render_template, request
import datetime, os

app = Flask(__name__)
LOG = "soc.log"

def log(event):
    with open(LOG, "a") as f:
        f.write(f"{datetime.datetime.now()} | {event}\n")

def caesar(text, shift):
    result = ""
    for c in text:
        if c.isalpha():
            base = 65 if c.isupper() else 97
            result += chr((ord(c) - base + shift) % 26 + base)
        else:
            result += c
    return result

def read_logs():
    if os.path.exists(LOG):
        with open(LOG) as f:
            return f.readlines()
    return []

@app.route("/", methods=["GET", "POST"])
def home():
    result = ""
    logs = read_logs()
    error = ""

    if request.method == "POST":
        text = request.form.get("text","")
        shift_val = request.form.get("shift","")
        action = request.form.get("action")

        if not shift_val.isdigit():
            error = "Shift must be a number!"
        else:
            shift = int(shift_val)

            if action == "Encrypt":
                result = caesar(text, shift)
                log("ENCRYPT")

            elif action == "Decrypt":
                result = caesar(text, -shift)
                log("DECRYPT")

            elif action == "Brute":
                result = "\n".join(
                    [f"Shift {i}: {caesar(text, -i)}" for i in range(26)]
                )
                log("BRUTE FORCE")

    return render_template("index.html", result=result, logs=logs, error=error)

if __name__ == "__main__":
    app.run(debug=True)
